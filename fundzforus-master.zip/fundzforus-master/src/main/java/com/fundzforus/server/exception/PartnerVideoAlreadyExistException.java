package com.fundzforus.server.exception;

public class PartnerVideoAlreadyExistException extends RuntimeException {
    public PartnerVideoAlreadyExistException(String message) {
        super(message);
    }
}
