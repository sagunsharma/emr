package com.fundzforus.server.exception;

public class PartnerLogoAlreadyExistException extends RuntimeException {
    public PartnerLogoAlreadyExistException(String message) {
        super(message);
    }
}
