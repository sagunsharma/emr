package com.fundzforus.server.exception;

public class PartnerImgAlreadyExistException extends RuntimeException {
    public PartnerImgAlreadyExistException(String message) {
        super(message);
    }
}
