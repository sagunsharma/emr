package com.fundzforus.server.exception;

public class UserProgramBookingNotFoundException extends RuntimeException {
    public UserProgramBookingNotFoundException(String message) {
        super(message);
    }
}
