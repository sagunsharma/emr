package com.fundzforus.server.util;

public enum MediaType {
    IMAGES,
    VIDEOS,
    PDFS;
}
