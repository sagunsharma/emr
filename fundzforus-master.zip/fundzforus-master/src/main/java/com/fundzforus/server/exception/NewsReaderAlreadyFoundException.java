package com.fundzforus.server.exception;

public class NewsReaderAlreadyFoundException extends RuntimeException {
    public NewsReaderAlreadyFoundException(String message) {
        super(message);
    }
}
