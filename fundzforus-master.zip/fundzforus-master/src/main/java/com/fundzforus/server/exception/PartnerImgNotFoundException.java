package com.fundzforus.server.exception;

public class PartnerImgNotFoundException extends RuntimeException {
    public PartnerImgNotFoundException(String message) {
        super(message);
    }
}
