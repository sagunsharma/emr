package com.fundzforus.server.exception;

public class PartnerLogoNotFoundException extends RuntimeException {
    public PartnerLogoNotFoundException(String message) {
        super(message);
    }
}
