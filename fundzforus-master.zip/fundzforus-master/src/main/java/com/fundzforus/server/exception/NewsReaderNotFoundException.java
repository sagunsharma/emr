package com.fundzforus.server.exception;

public class NewsReaderNotFoundException extends RuntimeException {
    public NewsReaderNotFoundException(String message) {
        super(message);
    }
}
