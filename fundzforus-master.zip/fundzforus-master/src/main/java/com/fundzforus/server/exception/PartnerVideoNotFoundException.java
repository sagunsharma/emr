package com.fundzforus.server.exception;

public class PartnerVideoNotFoundException extends RuntimeException {
    public PartnerVideoNotFoundException(String message) {
        super(message);
    }
}
