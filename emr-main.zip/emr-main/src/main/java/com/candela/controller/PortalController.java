package com.candela.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class PortalController {
    @GetMapping("/login")
    public String login(Model model) {
        return "login";
    }
    
    @GetMapping("/")
    public String home(Model model) {
    	ArrayList<Map<String, String>> apmnts = new ArrayList<Map<String, String>>();
    	Map<String, String> apmnt = new HashMap<String, String>();
    	apmnt.put("id", "1");
    	apmnt.put("patientname", "Mahesh Kumar");
    	apmnt.put("email", "test@gmail.com");
    	apmnt.put("phone", "8787676783");
    	apmnt.put("doctorname", "Rahul");
    	apmnt.put("department", "xyz");
    	apmnt.put("appointmenton", "29-Mar-2021");
    	apmnt.put("status", "inprogress");
    	apmnts.add(apmnt);
    	Map<String, String> apmnt2 = new HashMap<String, String>();
    	apmnt2.put("id", "2");
    	apmnt2.put("patientname", "Patient2");
    	apmnt2.put("email", "patient2@gmail.com");
    	apmnt2.put("phone", "8587676784");
    	apmnt2.put("doctorname", "Rahul");
    	apmnt2.put("department", "xyz");
    	apmnt2.put("appointmenton", "29-Mar-2021");
    	apmnt2.put("status", "inprogress");
    	apmnts.add(apmnt2);
    	Map<String, String> apmnt3 = new HashMap<String, String>();
    	apmnt3.put("id", "2");
    	apmnt3.put("patientname", "Patient3");
    	apmnt3.put("email", "patient2@gmail.com");
    	apmnt3.put("phone", "8887676764");
    	apmnt3.put("doctorname", "Rahul");
    	apmnt3.put("department", "xyz");
    	apmnt3.put("appointmenton", "29-Mar-2021");
    	apmnt3.put("status", "inprogress");
    	apmnts.add(apmnt3);
    	Map<String, String> apmnt4 = new HashMap<String, String>();
    	apmnt4.put("id", "2");
    	apmnt4.put("patientname", "Patient4");
    	apmnt4.put("email", "patient4@gmail.com");
    	apmnt4.put("phone", "6587676700");
    	apmnt4.put("doctorname", "Rahul");
    	apmnt4.put("department", "xyz");
    	apmnt4.put("appointmenton", "29-Mar-2021");
    	apmnt4.put("apmnt4", "inprogress");
    	apmnts.add(apmnt2);
        model.addAttribute("appointments", apmnts);

        return "home";
    }

    @GetMapping("/processencounter")
    public String processencounter(@RequestParam long id, Model model) {
    	ArrayList<Map<String, String>> apmnts = new ArrayList<Map<String, String>>();
    	Map<String, String> apmnt = new HashMap<String, String>();
    	apmnts.add(apmnt);
        model.addAttribute("patientname", "test");
        return "processencounter";
    }
    

}
